Question 2: 
To allow non-deterministic GET_WEATHER, change the "else" to "true" in Line 290. 